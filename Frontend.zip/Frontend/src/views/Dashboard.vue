<script setup>
import { ref, onBeforeMount } from "vue";

const review = ref([]);
const summary = ref([]);

onBeforeMount(async () => {
  try {
    const reviewResponse = await fetch(
      `${import.meta.env.VITE_BASE_URL}review/`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      }
    );
   

    if (reviewResponse.status === 200) {
      console.log("You have successfully logged in");

      const reviewData = await reviewResponse.json();
      review.value = reviewData;
    }
   else {
      console.error("Login failed");
    }

    const summaryResponse = await fetch(
      `${import.meta.env.VITE_BASE_URL}summary/`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      }
    );

    if (summaryResponse.status === 200) {
      console.log("Summary data fetched successfully");

      const summaryData = await summaryResponse.json();
      summary.value = summaryData;
    } else {
      console.error("Failed to fetch summary data");
    }
  } catch (error) {
    console.error("An error occurred:", error);
  }
});

</script>

<template>
  <div class="container mx-auto px-4">
    <section class="grid gap-7 grid-cols-2 grid-rows-2 mt-14">
      <div id="item-1">
        <div class="box-line" style="background-color: #ea5355"></div>
        <p class="item-name" style="color: #ea5355">Summary</p>
        <p class="item-number" v-if="summary.length > 0">
          {{ summary.length }}
        </p>
        <p class="item-number" v-else>0</p>
        <div class="box-icon" style="background-color: #ea5355">
          <img src="../assets/summary.png" />
        </div>
      </div>

      <div id="item-2">
        <div class="box-line" style="background-color: #f7b54c"></div>
        <p class="item-name" style="color: #f7b54c">Review</p>
        <p class="item-number" v-if="review.length > 0">{{ review.length }}</p>
        <p class="item-number" v-else>0</p>
        <div class="box-icon" style="background-color: #f7b54c">
          <img src="../assets/review.png" />
        </div>
      </div>

      <div id="item-3">
        <img src="../assets/userdashboard.png" />
      </div>
    </section>
  </div>
</template>

<style scoped>
#item-1 {
  grid-row-start: 1;
  grid-column-start: 1;
  grid-row-end: 2;
  grid-column-end: 3;
  width: 320px;
  height: 120px;
  background: #ffffff 0% 0% no-repeat padding-box;
  box-shadow: 0px 0px 20px #457aef26;
  border-radius: 20px;
  opacity: 1;
  /* border: 1px solid red; */
}
#item-2 {
  grid-row-start: 2;
  grid-column-start: 1;
  grid-row-end: 3;
  grid-column-end: 3;
  width: 320px;
  height: 120px;
  background: #ffffff 0% 0% no-repeat padding-box;
  box-shadow: 0px 0px 20px #457aef26;
  border-radius: 20px;
  opacity: 1;
}
#item-3 {
  background-color: #9cafe9;
  grid-row-start: 1;
  grid-column-start: 3;
  grid-row-end: 3;
  grid-column-end: 6;
  width: 900px;
  height: 270px;
  background: #457aef 0% 0% no-repeat padding-box;
  box-shadow: 0px 3px 24px #457aef5a;
  border-radius: 20px;
  opacity: 1;
}

#item-1 .item-name,
#item-2 .item-name {
  position: absolute;
  letter-spacing: 0.18px;
  opacity: 1;
  font: normal normal medium 18px/27px Poppins;
  font-family: Poppins;
  font-size: 18px;
  font-weight: 400;
  margin-top: 22px;
}

#item-1 .item-number,
#item-2 .item-number {
  position: absolute;
  font: normal normal 550 40px/60px Poppins;
  letter-spacing: 1.2px;
  color: #19335a;
  opacity: 1;
  margin-top: 45px;
}

#item-1 p,
#item-2 p {
  margin-left: 52px;
  /* margin-top:30px; */
}

#item-3 img {
  width: 340px;
  float: right;
  margin-right: 50px;
  margin-top: -40px;
}

.box-icon {
  width: 58px;
  height: 58px;
  border-radius: 15px;
  opacity: 1;
  float: right;
  margin-top: 10%;
  margin-bottom: 10%;
  margin-right: 8%;
}

.box-icon img {
  height: 35px;
  width: 35px;
  margin: auto auto;
  margin-top: 20%;
  margin-bottom: 20%;
  display: block;
}

.box-line {
  width: 8px;
  height: 75px;
  border-radius: 15px;
  float: left;
  margin-left: 8%;
  margin-top: 22px;
  margin-bottom: 22px;
}
</style>
