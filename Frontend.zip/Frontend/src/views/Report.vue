<script setup></script>

<template>

<h1 style="color: red;">Report</h1>
<h1>ทำ Release 3 จ้าาาาา</h1>

</template>

<style scoped>
h1{
    font-size: 80px;
}
</style>