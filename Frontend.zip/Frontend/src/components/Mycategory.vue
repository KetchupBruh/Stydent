<script setup>
import { ref, onBeforeMount } from "vue";
import moment from "moment";

const reviews = ref([]);
const summarys = ref([]);
const activeTab = ref("summary");
const summaryButtonColor = ref("#3498db"); // Color for the summary button
const reviewButtonColor = ref("#3498db"); // Color for the review button

const getsummary = async () => {
  try {
    const response = await fetch(
      `${import.meta.env.VITE_BASE_URL}summary/owner`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      }
    );

    if (response.status === 200) {
      const data = await response.json();
      summarys.value = data;
    } else {
      console.error("Get Summary failed");
    }
  } catch (error) {
    console.error("Error fetching summary data:", error);
  }
};

const getreview = async () => {
  try {
    const response = await fetch(
      `${import.meta.env.VITE_BASE_URL}review/owner`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      }
    );

    if (response.status === 200) {
      const data = await response.json();
      reviews.value = data;
    } else {
      console.error("Get Review failed");
    }
  } catch (error) {
    console.error("Error fetching review data:", error);
  }
};

onBeforeMount(() => {
  activeTab.value = "summary";
  updateButtonColors();
  getsummary();
  getreview();
});

const switchTab = (tab) => {
  activeTab.value = tab;
  updateButtonColors();
};

const updateButtonColors = () => {
  summaryButtonColor.value =
    activeTab.value === "summary" ? "#FFFFFF" : "#E2E6F4";
  reviewButtonColor.value =
    activeTab.value === "review" ? "#FFFFFF" : "#E2E6F4";
};
</script>

<template>
  <div class="container mx-auto mt-28 mt-8 mb-10">
    <div class="line-review"></div>
    <p class="review">My Category</p>

    <div class="all">
    <button
      :style="{ backgroundColor: summaryButtonColor , color: activeTab === 'summary' ? '#4675c0' : '#B8BFD6'}"
      @click="switchTab('summary')"
      class="font-light "
    >
      Summary <span class="count" :class="{ 'inactive': activeTab !== 'summary' }">{{ summarys.length }}</span>
    </button>
    
    <button
      :style="{ backgroundColor: reviewButtonColor , color: activeTab === 'review' ? '#4675c0' : '#B8BFD6' }"
      @click="switchTab('review')"
      class="font-light "
    >
      Review <span class="count" :class="{ 'inactive': activeTab !== 'review' }">{{ reviews.length }}</span>
    </button>

    <!-- ส่วนของกล่อง summary -->
    <div class="box" v-if="activeTab === 'summary' && summarys.length > 0">
      <div class="review-box" v-for="summary in summarys" :key="summary.id">
        Course Full Name: {{summary.courseName}}  {{ summary.courseFullName }} <br>File Description:
        {{ summary.fileDescription }}<br> File Created On:
        {{
          moment(summary.fileCreatedOn)
            .locale("th")
            .format("DD MMMM YYYY, HH:mm a")
        }}
        <hr />
      </div>
    </div>

    <div v-else-if="activeTab === 'summary'" class="box review-box no-data">No summary</div>

    <!-- ส่วนของกล่อง review -->
    <div class="box" v-if="activeTab === 'review' && reviews.length > 0">
      <div class="review-box" v-for="review in reviews" :key="review.id">
        <p>
          Course Full Name: {{ review.courseFullName }} Grades Received:
          {{ review.gradesReceived }}  Instructor Name:
          {{ review.instructorName }} Rating: {{ review.rating }} Work:
          {{ review.work }} Review Description:
          {{ review.reviewDescription }} Review Created On:
          {{
            moment(review.reviewCreatedOn)
              .locale("th")
              .format("DD MMMM YYYY, HH:mm a")
          }}
        </p>
        <hr />
      </div>
    </div>

    <div v-else-if="activeTab === 'review'" class="box review-box no-data">No review</div>
  </div>

    <!-- <div
          v-if="activeTab === 'review' && reviews.length > 0"
          class="review-container"
        >
          <div v-for="review in reviews" :key="review.id">
            <p>Course Full Name: {{ review.courseFullName }}</p>
            <p>Grades Received: {{ review.gradesReceived }}</p>
            <p>Instructor Name: {{ review.instructorName }}</p>
            <p>Rating: {{ review.rating }}</p>
            <p>Work: {{ review.work }}</p>
            <p>Review Description: {{ review.reviewDescription }}</p>
            <p>
              Review Created On:
              {{
                moment(review.reviewCreatedOn)
                  .locale("th")
                  .format("DD MMMM YYYY, HH:mm a")
              }}
            </p>
            <hr />
          </div>
        </div>
        <div v-else-if="activeTab === 'review'" class="no-data">No review</div> -->
  </div>
</template>

<style scoped>

.all{
position: absolute;
margin-left: 10px;
margin-top: 10px;
}

button {
  color: #000000;
  font-size: 16px;
  padding-left: 20px;
  padding-right: 20px;
  /* margin-bottom: 10px; */
  /* margin-top: 15px; */
  /* margin-left: 5px; */
  margin-right: 12px;
  cursor: pointer;
  border: none;
  border-radius: 15px 15px 0px 0px;
  height: 50px;
  position: relative;
}


.no-data {
  color: #e74c3c;
  font-size: 18px;
  font-weight: bold;
  z-index: 1;
}

.line-review {
  position: absolute;
  width: 8px;
  height: 39px;
  border-radius: 15px;
  margin-left: 15px;
  background-color: #4675c0;
}

.review {
  margin-left: 40px;
  color: var(--unnamed-color-19335a);
  text-align: left;
  font: normal normal 600 26px/39px Poppins;
  letter-spacing: 1.04px;
  color: #19335a;
  opacity: 1;
  margin-bottom: 20px;
}

.review-box {
  position: relative;
  width: 1188px;
  /* height: 328px; */
  background: #fafafa 0% 0% no-repeat padding-box;
  box-shadow: 0px 0px 5px #efefef;
  border: 1px solid #efefef;
  border-radius: 20px;
  opacity: 1;
  /* margin-top: 10px; */
  margin-bottom: 30px;
  padding: 20px;
  white-space: pre-line; /* ทำให้ข้อความขึ้นบรรทัดใหม่ตามตำแหน่งของ "\n" */
  word-wrap: break-word; /* ทำให้ข้อความขึ้นบรรทัดใหม่ตามขอบกล่อง */
  overflow: hidden;
}

.box {
  position: relative;
  width: 1266px;
  /* height: 849px; */
  /* margin-top: 25px; */
  margin-left: auto;
  margin-right: auto;
  padding-bottom: 30px;
  padding-top: 40px;
  background: #ffffff 0% 0% no-repeat padding-box;
  box-shadow: 0px 0px 15px #457aef0d;
  border-radius: 0px 20px 20px 20px;
  opacity: 1;

  display: flex;
  flex-direction: column;
  align-items: center;
}

.box-content {
  margin-left: -93%;
}

.count {
  margin-left: 5px;
  padding: 4px 10px 4px 10px;
  border-radius: 8px; 
  background-color: #4675c0;
  color: white;
  font-size: 12px;
  font-weight: 800;
}

.inactive {
  background-color: #B8BFD6; 
  opacity: 0.5;
}

</style>
